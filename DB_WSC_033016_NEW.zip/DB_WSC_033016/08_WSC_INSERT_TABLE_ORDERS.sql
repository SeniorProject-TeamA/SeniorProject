/*********************************************************************************************
 *Williams Specialty Company - Business Process Automation                                   *
 *MySQL Insert Values into table orders                                                      *
 *********************************************************************************************
 **********************************************UPDATE*****************************************
 *March 28, 2016 - Joe Gibson -Created                                                       *
 *March 30, 2016 - John Boley - Updated the time field                                       *
 *********************************************************************************************/

INSERT INTO `williams`.`orders` (cusID, invID, empID, typID, Details, Quantity, Complete)
VALUES ('7', '12', '6', '12', 'Rogers Intramural Champions 2016', '12', 1);

INSERT INTO `williams`.`orders` (cusID, invID, empID, typID, Details, Quantity, Complete)
VALUES ('10', '4', '10', '11', 'Stencil Logo Flaming Basketball Through Hoop. Phrase "En Fuego" below logo.', '1', 1);

INSERT INTO `williams`.`orders` (cusID, invID, empID, typID, Details, Quantity, Complete)
VALUES ('2', '16', 1, '12', 'Top Plate: Congratulations; Font: Castellar; Bottom Plate: Top Sales Q4, 2015; Font: Castellar; Picture: Framed Dollar Bill.', '1', 1);

INSERT INTO `williams`.`orders` (cusID, invID, empID, typID, Details, Quantity, Complete)
VALUES ('1', '2', '9', '11', 'Chevrolet Bowtie: Front; Phrase: Nothin Runs Like A Chevy: Below.', '1', 1);

INSERT INTO `williams`.`orders` (cusID, invID, empID, typID, Details, Quantity, Complete)
VALUES ('14', '7', '12', '11', 'Flier: Custom Format Provided by Customer: See attached', '100', 1);

