/*********************************************************************************************
 *Williams Specialty Company - Business Process Automation                                   *
 *MySQL Insert Values into table payments                                                    *
 *********************************************************************************************
 **********************************************UPDATES****************************************
 *March 30th, 2016 - Joe Gibson - Created                                                    *
 *********************************************************************************************/

INSERT INTO `williams`.`payments` (ordID, empID, typID, Paid, Due)
VALUES ('1', '1', '5', '0.00', '540.97');

INSERT INTO `williams`.`payments` (ordID, empID, typID, Paid, Due)
VALUES ('2', '6', '6.', '22.50', '202.50');

INSERT INTO `williams`.`payments` (ordID, empID, typID, Paid, Due)
VALUES ('3', '9', '7', '133.50', '0.00');

INSERT INTO `williams`.`payments` (ordID, empID, typID, Paid, Due)
VALUES ('4', '10', '6.', '18.50', '166.50');

INSERT INTO `williams`.`payments` (ordID, empID, typID, Paid, Due)
VALUES ('5', '12', '5', '0.00', '200.98');

