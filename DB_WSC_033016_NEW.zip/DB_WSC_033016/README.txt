To 'run' a script, do the following:

1. from the phpmyadmin home, click on the 'Import' tab in top banner.
2. select 'choose file' (automatic format is sql).
3. click 'Go'.
4. Script is imported and applied to the williams database.


1.  Run 01_WSC-BPA_DB_xxxxxx_CREATE.sql (where xxxxxx is the date in form mmddyy)
2.  Run 02_WSC_ALTER_STATEMENTS.sql
3.  Run 03_WSC_INSERT_TABLE_TYPE.sql
4.  Run 04_WSC_INSERT_TABLE_EMPLOYEE.sql
5.  Run 05_WSC_INSERT_TABLE_CREDENTIALS.sql
6.  Run 06_WSC_INSERT_TABLE_CUSTOMER.sql
7.  Run 07_WSC_INSERT_TABLE_INVENTORY.sql
8.  Run 08_WSC_INSERT_ORDERS.sql
9.  RUN 09_WSC_INSERT_NOTIFICATIONS.sql
10. RUN 10_WSC_INSERT_PAYMENTS.sql

