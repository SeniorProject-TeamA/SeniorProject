/*********************************************************************************************
 *Williams Specialty Company - Business Process Automation                                   *
 *MySQL Insert Values into table credentials                                                 *
 *********************************************************************************************
 **********************************************UPDATES****************************************
 *March 29th, 2016 - Joe Gibson - Created                                                    *
 ********************************************************************************************/ 

INSERT INTO `williams`.`credentials`
VALUES ('1', 'Provo12');

INSERT INTO `williams`.`credentials` 
VALUES ('2', 'Marvel02');

INSERT INTO `williams`.`credentials` 
VALUES ('3', 'NoisyLotus1');

INSERT INTO `williams`.`credentials`
VALUES ('4', 'Typical11');

INSERT INTO `williams`.`credentials` 
VALUES ('5', 'pAradise77');

INSERT INTO `williams`.`credentials` 
VALUES ('6', 'taranTula1965');

INSERT INTO `williams`.`credentials` 
VALUES ('7', 'mo22erellaM3lt');

INSERT INTO `williams`.`credentials` 
VALUES ('8', '3ggPlants');

INSERT INTO `williams`.`credentials` 
VALUES ('9', 'Charg3rsRul3');

INSERT INTO `williams`.`credentials` 
VALUES ('10', 'Silv3rAndBlack');

INSERT INTO `williams`.`credentials` 
VALUES ('11', 'pretzy1');

INSERT INTO `williams`.`credentials` 
VALUES ('12', 'Gh0st1y');


